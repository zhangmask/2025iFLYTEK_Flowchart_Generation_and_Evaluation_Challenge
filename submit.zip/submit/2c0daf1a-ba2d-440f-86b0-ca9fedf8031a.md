```mermaid
flowchart
A[开始] --> B[迪士尼宣布收购]
B --> C{是否获得董事会批准}
C -->|是| D[进行反垄断评估]
C -->|是| E{是否获得Marvel股东批准}
E -->|是| F[迪士尼获得Marvel资产]
F --> G[Marvel CEO继续管理资产]
G --> H[整合迪士尼业务]
H --> I[结束]
E -->|是| J[交易终止]
```
